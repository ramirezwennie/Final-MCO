<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Auth::login');
//Authentication routes

$routes->get('/login', 'Auth::login');
$routes->get('/register', 'Auth::register');

$routes->post('/store', 'Auth::store');
$routes->post('/authLogin', 'Auth::authLogin');

$routes->get('/logout', 'Auth::logout');

$routes->get('/feed', 'Post::feed');
$routes->post('/post/create', 'Post::create');

$routes->post('/comment', 'Post::comment');
$routes->get('post/react/(:num)', 'Post::react/$1');

$routes->get('/add-friend/(:num)', 'Friend::add/$1');
$routes->get('/remove-friend/(:num)', 'Friend::remove/$1');