<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>FRENSTERS - Dashboard</title>

<style>
/* (YOUR CSS UNCHANGED FOR CLEANNESS) */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: Arial, sans-serif;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    min-height: 100vh;
}

.container {
    max-width: 1200px;
    margin: auto;
    display: grid;
    grid-template-columns: 300px 1fr 300px;
    gap: 20px;
    padding: 20px;
}

.header {
    grid-column: 1 / -1;
    background: white;
    padding: 15px 25px;
    border-radius: 15px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.logo {
    font-size: 24px;
    font-weight: bold;
    color: #667eea;
}

.logout-btn {
    background: #ff6b6b;
    color: white;
    padding: 10px 20px;
    border-radius: 20px;
    text-decoration: none;
}

.sidebar {
    background: white;
    border-radius: 15px;
    padding: 20px;
}

.profile-name {
    font-size: 20px;
    font-weight: bold;
    margin-bottom: 5px;
}

.profile-bio {
    font-size: 14px;
    margin-bottom: 15px;
    color: #666;
}

.user-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 12px;
    background: #f3f3ff;
    border-radius: 10px;
    margin-bottom: 10px;
}

.username {
    font-weight: bold;
}

.user-actions {
    display: flex;
    gap: 6px;
}

.action-btn {
    padding: 5px 10px;
    border-radius: 15px;
    font-size: 12px;
    text-decoration: none;
    color: white;
}

.add-btn { background: #48bb78; }
.remove-btn { background: #f56565; }

.create-post {
    background: white;
    padding: 20px;
    border-radius: 15px;
}

textarea {
    width: 100%;
    padding: 10px;
    border-radius: 10px;
    border: 1px solid #ccc;
    margin-bottom: 10px;
}

.post-btn {
    background: #667eea;
    color: white;
    padding: 10px 18px;
    border: none;
    border-radius: 10px;
    font-size: 14px;
    cursor: pointer;
}

.post-card {
    background: white;
    padding: 15px;
    border-radius: 15px;
    margin-top: 15px;
}

.post-author {
    font-weight: bold;
    margin-bottom: 5px;
}

.post-content {
    margin: 10px 0;
}

.like-btn {
    background: #ed64a6;
    color: white;
    padding: 6px 12px;
    border-radius: 20px;
    text-decoration: none;
    font-size: 13px;
}

.comment-form {
    display: flex;
    gap: 8px;
    margin-top: 10px;
}

.comment-form input {
    flex: 1;
    padding: 8px;
    border-radius: 20px;
    border: 1px solid #ccc;
}

.comment-btn {
    background: #48bb78;
    color: white;
    border: none;
    padding: 8px 14px;
    border-radius: 20px;
}
</style>

</head>
<body>

<div class="container">

    <!-- HEADER -->
    <div class="header">
        <div class="logo">FRENSTERS</div>
        <a href="/logout" class="logout-btn">Logout</a>
    </div>

    <!-- LEFT -->
    <div class="sidebar">
        <div class="profile-name">
            <?= session()->get('username') ?>
        </div>
        <div class="profile-bio">
            Welcome to Frensters 👋
        </div>

        <h3>👥 Friends</h3>

        <?php foreach($users as $user): ?>
        <div class="user-item">
            <span class="username">
                <?= htmlspecialchars($user['username']) ?>
            </span>

            <div class="user-actions">
                <a href="/add-friend/<?= $user['id'] ?>" class="action-btn add-btn">Add</a>
                <a href="/remove-friend/<?= $user['id'] ?>" class="action-btn remove-btn">Remove</a>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <!-- CENTER -->
    <div class="create-post">

        <h3>✨ What's on your mind?</h3>

        <form method="post" action="/post/create" enctype="multipart/form-data">
            <textarea name="content" placeholder="Share something..." required></textarea>
            <input type="file" name="image"><br><br>
            <button type="submit" class="post-btn">Post</button>
        </form>

        <!-- POSTS -->
        <?php foreach($posts as $post): ?>
        <div class="post-card">

            <div class="post-author"><?= $post['username'] ?></div>
            <div class="post-content"><?= $post['content'] ?></div>

            <?php if (!empty($post['image'])): ?>
            <img src="/uploads/<?= $post['image'] ?>" 
                style="width:100%; max-width:100%; height:auto; 
                        max-height:400px; object-fit:cover; 
                        margin-top:10px; border-radius:10px; display:block;">
             <?php endif; ?>


            <!-- ✅ FIXED LIKE BUTTON -->
            <a href="/post/react/<?= $post['id'] ?>" class="like-btn">
                ❤️ Like
            </a>

            <!-- COMMENTS -->
            <form method="post" action="/comment" class="comment-form">
                <input type="hidden" name="post_id" value="<?= $post['id'] ?>">
                <input type="text" name="comment" placeholder="Comment..." required>
                <button class="comment-btn">Comment</button>
            </form>

            <!-- DISPLAY COMMENTS -->
            <?php if (!empty($comments[$post['id']])): ?>
                <?php foreach ($comments[$post['id']] as $c): ?>
                    <div style="
                        background:#f3f3ff;
                        padding:6px 10px;
                        border-radius:10px;
                        margin-top:5px;
                        font-size:13px;
                    ">
                        <b><?= htmlspecialchars($c['username']) ?>:</b>
                        <?= htmlspecialchars($c['comment']) ?>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>

        </div>
        <?php endforeach; ?>

    </div>

    <!-- RIGHT -->
    <div class="sidebar">
        <h3>Suggestions</h3>
        <p>Coming soon...</p>
    </div>

</div>

</body>
</html>