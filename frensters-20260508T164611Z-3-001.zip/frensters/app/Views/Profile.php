<!DOCTYPE html>
<html>
<head>
    <title>FRENSTERS Profile</title>
    <style>
        body{
            font-family:Arial;
            background:#f0f2f5;
            display:flex;
            justify-content:center;
            align-items:center;
            height:100vh;
        }
        .card{
            background:white;
            padding:20px;
            border-radius:10px;
            width:300px;
            text-align:center;
        }
        .name{
            font-size:20px;
            font-weight:bold;
            color:#1877f2;
        }
    </style>
</head>
<body>

<div class="card">
    <div class="name">FRENSTERS PROFILE</div>
    <p>Username: <?= $user['username'] ?? '' ?></p>
    <p>Email: <?= $user['email'] ?? '' ?></p>
</div>

</body>
</html>