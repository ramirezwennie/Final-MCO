<?php

namespace App\Models;

use CodeIgniter\Model;

class PostModel extends Model
{
    protected $table = 'posts';
    protected $primaryKey = 'id';

    protected $allowedFields = [
        'user_id',
        'content',
        'image',
        'created_at'
    ];

    protected $useTimestamps = false;
}