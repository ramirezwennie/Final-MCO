<?php

namespace App\Controllers;

use Config\Database;

class Friend extends BaseController
{
    public function add($id)
    {
        $db = Database::connect();
        $user_id = session()->get('user_id');

        // check if already exists
        $exists = $db->table('friends')
            ->where('user_id', $user_id)
            ->where('friend_id', $id)
            ->get()
            ->getRow();

        if (!$exists) {
            $db->table('friends')->insert([
                'user_id' => $user_id,
                'friend_id' => $id,
                'status' => 'pending'
            ]);
        }

        return redirect()->to('/feed');
    }

    public function remove($id)
    {
        $db = Database::connect();
        $user_id = session()->get('user_id');

        $db->table('friends')
            ->where('user_id', $user_id)
            ->where('friend_id', $id)
            ->delete();

        return redirect()->to('/feed');
    }

    public function accept($id)
    {
        $db = Database::connect();
        $user_id = session()->get('user_id');

        $db->table('friends')
            ->where('user_id', $id)
            ->where('friend_id', $user_id)
            ->update([
                'status' => 'accepted'
            ]);

        return redirect()->to('/feed');
    }
}