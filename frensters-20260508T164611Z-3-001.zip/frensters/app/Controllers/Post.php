<?php

namespace App\Controllers;

use App\Models\PostModel;
use App\Models\UserModel;

class Post extends BaseController
{
    public function feed()
    {
        if (!session()->get('user_id')) {
            return redirect()->to('/login');
        }

        $postModel = new PostModel();
        $userModel = new UserModel();
        $db = \Config\Database::connect();

        // POSTS
        $data['posts'] = $postModel
            ->select('posts.*, users.username')
            ->join('users', 'users.id = posts.user_id')
            ->orderBy('posts.id', 'DESC')
            ->findAll();

        // USERS
        $data['users'] = $userModel
            ->where('id !=', session()->get('user_id'))
            ->findAll();

        // COMMENTS (JOIN USERS)
        $comments = $db->table('comments')
            ->select('comments.*, users.username')
            ->join('users', 'users.id = comments.user_id')
            ->orderBy('comments.id', 'ASC')
            ->get()
            ->getResultArray();

        // GROUP COMMENTS BY POST ID
        $groupedComments = [];

        foreach ($comments as $c) {
            $groupedComments[$c['post_id']][] = $c;
        }

        $data['comments'] = $groupedComments;

        $data['current_user'] = session()->get('username');

        return view('dashboard', $data);
    }

    public function create()
    {
        $model = new PostModel();

        $file = $this->request->getFile('image');
        $imageName = null;

        if ($file && $file->isValid() && !$file->hasMoved()) {
            $imageName = $file->getRandomName();
            $file->move('uploads', $imageName);
        }

        $model->save([
            'user_id'    => session()->get('user_id'),
            'content'    => $this->request->getPost('content'),
            'image'      => $imageName,
            'created_at' => date('Y-m-d H:i:s')
        ]);

        return redirect()->to('/feed');
    }

    public function comment()
    {
        $db = \Config\Database::connect();

        $db->table('comments')->insert([
            'post_id'    => $this->request->getPost('post_id'),
            'user_id'    => session()->get('user_id'),
            'comment'    => $this->request->getPost('comment'),
            'created_at' => date('Y-m-d H:i:s')
        ]);

        return redirect()->to('/feed');
    }

    public function react($id)
    {
        $db = \Config\Database::connect();

        $user_id = session()->get('user_id');

        $exists = $db->table('reactions')
            ->where('post_id', $id)
            ->where('user_id', $user_id)
            ->get()
            ->getRow();

        if ($exists) {
            $db->table('reactions')
                ->where('post_id', $id)
                ->where('user_id', $user_id)
                ->delete();
        } else {
            $db->table('reactions')->insert([
                'post_id' => $id,
                'user_id' => $user_id,
                'type'    => 'like'
            ]);
        }

        return redirect()->to('/feed');
    }
}