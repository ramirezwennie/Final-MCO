<?php

namespace App\Controllers;

use App\Models\UserModel;

class Profile extends BaseController
{
    public function index()
    {
        $userId = session()->get('user_id');

        if (!$userId) {
            return redirect()->to('/login');
        }

        $model = new UserModel();
        $user = $model->find($userId);

        return view('profile', ['user' => $user]);
    }
}